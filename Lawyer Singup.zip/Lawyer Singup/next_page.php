<?php
include "../conn.php";
session_start();

if (!isset($_SESSION['languages_spoken']) || !isset($_SESSION['availability'])) {
    // Redirect back to the form if session variables are not set
    header("Location: index.php");
    exit();
}

$languages_spoken = $_SESSION['languages_spoken'];
$availability = $_SESSION['availability'];

// Insert into the database
$query = "INSERT INTO lawyer (language, availability) VALUES (?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $languages_spoken, $availability);

if ($stmt->execute()) {
    echo "Data inserted successfully.";
} else {
    echo "Error: " . $stmt->error;
}

// Clear session variables
unset($_SESSION['languages_spoken']);
unset($_SESSION['availability']);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Next Page</title>
    <link rel="stylesheet" href="../styles1.css">
</head>
<body>
    <h1>Next Step in Signup Process</h1>
    <!-- Add your content here for the next step -->
</body>
</html>
