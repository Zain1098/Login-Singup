<?php
include "../conn.php";

// Fetch data from the database
$query = "SELECT language, availability FROM lawyer";
$result = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lawyer Availability</title>
    <link rel="stylesheet" href="../styles1.css">
</head>
<body>
    <h1>Lawyer Availability</h1>
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $languages_spoken = htmlspecialchars($row['language']);
            $availability = json_decode($row['availability'], true);

            echo "<div class='lawyer'>";
            echo "<p><strong>Languages Spoken:</strong> $languages_spoken</p>";

            if ($availability) {
                $availabilityDisplay = [];
                foreach ($availability as $slot) {
                    $availabilityDisplay[] = $slot['day'] . ": " . $slot['start'] . " to " . $slot['end'];
                }
                $availabilityString = implode('<br>', $availabilityDisplay);
                echo "<p><strong>Availability:</strong><br> $availabilityString</p>";
            }

            echo "</div>";
        }
    } else {
        echo "<p>No data found.</p>";
    }
    ?>
</body>
</html>
